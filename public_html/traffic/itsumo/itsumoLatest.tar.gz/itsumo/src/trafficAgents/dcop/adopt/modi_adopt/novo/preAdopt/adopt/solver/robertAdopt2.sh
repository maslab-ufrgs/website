#!/bin/bash

echo "Vou comecar !!!!"

java -classpath /home/user/work/algoritmos/adopt/modi_adopt/ adopt.solver.Simulator $1 $2 $3

echo "It's done, great master ROBERT !!!!"
